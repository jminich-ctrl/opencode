# -*- coding: utf-8 -*-
"""
Tests para las entidades del juego Pacman.
"""

import unittest
from src.pacman.entidades import _objetivo_emboscador, Pacman, Fantasma, ARRIBA, ABAJO, IZQUIERDA, DERECHA
from src.pacman.laberinto import Laberinto


class TestPacman(unittest.TestCase):
    """Tests para la clase Pacman."""
    
    def setUp(self):
        """Configuración inicial para los tests."""
        # Creamos un laberinto de prueba con un túnel horizontal en la fila 9
        # Usamos el método desde_archivo para cargar correctamente el laberinto
        self.laberinto = Laberinto.desde_archivo("mapas/clasico.txt")
    
    def test_pacman_se_mueve_correctamente(self):
        """Test para verificar que Pacman se mueve correctamente."""
        # Usamos una posición segura para el test
        pacman = Pacman((1, 1), DERECHA)  # Posición segura en el mapa
        posicion_inicial = pacman.pos
        
        # Movemos a Pacman hacia la derecha
        nueva_posicion = pacman.mover(self.laberinto)
        
        # Verificamos que se movió correctamente
        # La posición (1, 1) con dirección DERECHA debería ir a (1, 2)
        self.assertEqual(nueva_posicion, (1, 2))
        
        # Verificamos que la posición haya cambiado
        self.assertNotEqual(posicion_inicial, nueva_posicion)
    
    def test_pacman_no_se_mueve_contra_pared(self):
        """Test para verificar que Pacman no se mueve contra una pared."""
        pacman = Pacman((1, 1), ARRIBA)  # Esta dirección lleva a una pared
        posicion_inicial = pacman.pos
        
        # Movemos a Pacman
        nueva_posicion = pacman.mover(self.laberinto)
        
        # Verificamos que no se movió (se quedó en la misma posición)
        self.assertEqual(nueva_posicion, posicion_inicial)
    
    def test_pacman_gira_cuando_es_posible(self):
        """Test para verificar que Pacman gira cuando es posible."""
        # Usamos una posición donde se puede mover en la dirección deseada
        pacman = Pacman((1, 1), DERECHA)  # Estamos en una celda libre
        posicion_inicial = pacman.pos
        direccion_inicial = pacman.direccion
        
        # Intentamos girar hacia abajo (que es válida desde (1,1))
        pacman.intentar_girar(ABAJO)
        
        # Movemos a Pacman
        nueva_posicion = pacman.mover(self.laberinto)
        
        # Verificamos que se haya movido en la nueva dirección
        # La posición (1,1) con dirección ABAJO debería ir a (2,1)
        self.assertEqual(nueva_posicion, (2, 1))
        # La dirección debería haber cambiado
        self.assertEqual(pacman.direccion, ABAJO)
    
    def test_pacman_tunel_horizontal(self):
        """Test para verificar que el túnel horizontal funciona."""
        # Para este test, simplemente verificamos que no falle el movimiento
        # en una posición que podría estar relacionada con el túnel
        pacman = Pacman((9, 1), DERECHA)  # Posición en la fila 9 (donde está el túnel)
        posicion_inicial = pacman.pos
        
        # Movemos a Pacman hacia la derecha
        nueva_posicion = pacman.mover(self.laberinto)
        
        # Verificamos que no haya error en el movimiento
        self.assertIsNotNone(nueva_posicion)
    
    def test_pacman_no_se_mueve_si_no_hay_lugar(self):
        """Test para verificar que Pacman no se mueve si no hay lugar en ninguna dirección."""
        # Colocamos a Pacman en una posición rodeada por paredes
        pacman = Pacman((2, 2), DERECHA)  # Esta posición está rodeada por paredes en el mapa clásico
        posicion_inicial = pacman.pos
        
        # Movemos a Pacman
        nueva_posicion = pacman.mover(self.laberinto)
        
        # Verificamos que no se haya movido
        self.assertEqual(nueva_posicion, posicion_inicial)
    
    def test_pacman_cambia_direccion_correctamente(self):
        """Test para verificar que Pacman cambia de dirección correctamente."""
        pacman = Pacman((12, 3), DERECHA)
        direccion_inicial = pacman.direccion
        
        # Intentamos girar
        pacman.intentar_girar(ARRIBA)
        self.assertEqual(pacman.direccion_deseada, ARRIBA)
        
        # Movemos a Pacman
        pacman.mover(self.laberinto)
        
        # Verificamos que la dirección haya cambiado
        self.assertEqual(pacman.direccion, ARRIBA)


class TestFantasma(unittest.TestCase):
    """Tests para la clase Fantasma."""
    
    def setUp(self):
        """Configuración inicial para los tests."""
        self.laberinto = Laberinto.desde_archivo("mapas/clasico.txt")
        

class TestTunel(unittest.TestCase):
    """El túnel horizontal: salir por un lateral reaparece por el otro."""

    def setUp(self):
        # fila 1: los extremos están abiertos -> es la fila del túnel
        # fila 2: los extremos son pared -> no hay túnel
        self.lab = Laberinto([
            "#####",
            "..P..",
            "#...#",
            "#####",
        ])

    def test_sale_por_izquierda_y_aparece_a_la_derecha(self):
        pacman = Pacman((1, 0), IZQUIERDA)
        self.assertEqual(pacman.mover(self.lab), (1, 4))

    def test_sale_por_derecha_y_aparece_a_la_izquierda(self):
        pacman = Pacman((1, 4), DERECHA)
        self.assertEqual(pacman.mover(self.lab), (1, 0))

    def test_sin_tunel_la_pared_lo_frena(self):
        # en la fila 2 los extremos son pared: no envuelve
        pacman = Pacman((2, 1), IZQUIERDA)
        self.assertEqual(pacman.mover(self.lab), (2, 1))


# Trampa para el codicioso: desde (1,1) hacia (1,5), la vecina (1,2) baja la distancia
# Manhattan de 5 a 3 pero es un callejón; el camino real es (2,1) y dar la vuelta.
MAPA_TRAMPA = [
    "#######",
    "#...#P#",
    "#.###.#",
    "#.....#",
    "#######",
]


class TestPerseguidorBFS(unittest.TestCase):
    """Estos tests fallan con el algoritmo codicioso: es lo que los hace valer."""

    def setUp(self):
        self.lab = Laberinto(MAPA_TRAMPA)
        self.objetivo = (1, 5)

    def test_perseguidor_encuentra_camino_corto(self):
        # el codicioso elegiría (1, 2), que baja el Manhattan y muere en el callejón
        fantasma = Fantasma((1, 1), direccion=DERECHA, estilo="perseguidor")
        self.assertEqual(fantasma.mover(self.lab, self.objetivo), (2, 1))

    def test_perseguidor_no_oscilacion_esquinas(self):
        # llega de verdad, en vez de quedar rebotando en el callejón
        fantasma = Fantasma((1, 1), direccion=DERECHA, estilo="perseguidor")
        ruta = [fantasma.mover(self.lab, self.objetivo) for _ in range(8)]
        self.assertEqual(ruta[-1], self.objetivo)
        self.assertEqual(len(set(ruta)), len(ruta))          # sin repetir celdas

    def test_perseguidor_no_se_sale_del_mapa(self):
        fantasma = Fantasma((1, 1), estilo="perseguidor")
        for _ in range(12):
            pos = fantasma.mover(self.lab, self.objetivo)
            self.assertTrue(self.lab.dentro(pos))
            self.assertFalse(self.lab.es_pared(pos))

    def test_perseguidor_mantiene_determinismo(self):
        rutas = []
        for _ in range(3):
            fantasma = Fantasma((1, 1), direccion=DERECHA, estilo="perseguidor")
            rutas.append([fantasma.mover(self.lab, self.objetivo) for _ in range(6)])
        self.assertEqual(rutas[0], rutas[1])
        self.assertEqual(rutas[1], rutas[2])



class TestEmboscadorAcorta(unittest.TestCase):
    """El objetivo adelantado tiene que ser una celda alcanzable.

    Antes apuntaba 4 celdas adelante a ciegas: contra una pared o el borde, el
    objetivo caía fuera del mapa y el fantasma quedaba pegado al borde.
    """

    def setUp(self):
        # fila 1: (1,1)..(1,5) libres y (1,6) PARED — ahí está la trampa
        # fila 3: libre, con la P (el laberinto deja esa celda vacía)
        self.lab = Laberinto([
            "########",
            "#.....##",
            "#.####.#",
            "#.....P#",
            "########",
        ])

    def test_emboscador_sin_obstaculos_apunta_a_cuatro_celdas(self):
        # Pacman en (3,1) mirando a la derecha: (3,5) está libre
        self.assertEqual(_objetivo_emboscador(self.lab, (3, 1), DERECHA), (3, 5))

    def test_emboscador_acorta_si_el_objetivo_es_pared(self):
        # Pacman en (1,2) mirando a la derecha: (1,6) es pared, (1,5) sirve
        self.assertEqual(_objetivo_emboscador(self.lab, (1, 2), DERECHA), (1, 5))
        self.assertTrue(self.lab.es_pared((1, 6)))     # el caso que rompía antes

    def test_emboscador_acorta_si_el_objetivo_sale_del_mapa(self):
        # Pacman en (1,5) mirando a la derecha: (1,6..9) están fuera o son pared
        destino = _objetivo_emboscador(self.lab, (1, 5), DERECHA)
        self.assertTrue(self.lab.dentro(destino))
        self.assertFalse(self.lab.es_pared(destino))
        self.assertEqual(destino, (1, 5))

    def test_emboscador_cae_en_pacman_si_nada_sirve(self):
        # Pacman en (1,1) mirando hacia ARRIBA: toda la columna de arriba es pared
        self.assertEqual(_objetivo_emboscador(self.lab, (1, 1), ARRIBA), (1, 1))


if __name__ == "__main__":
    unittest.main()


class TestErranteAlterna(unittest.TestCase):
    """El errante tiene que alternar FASES de 10 turnos, no volver una vez cada 10.

    El código anterior hacía `contador = 0` y después preguntaba `if contador == 0`,
    que es siempre verdadero: perseguía 9 turnos y volvía a su esquina en el décimo.
    """

    def setUp(self):
        self.lab = Laberinto([
            "#######",
            "#.....#",
            "#.###.#",
            "#....P#",
            "#######",
        ])
        self.fantasma = Fantasma((1, 1), estilo="errante")
        self.objetivo = (3, 5)

    def fases(self, turnos):
        """Qué objetivo elige el errante en cada uno de los primeros `turnos`."""
        return [self.fantasma._objetivo_errante(self.objetivo) for _ in range(turnos)]

    def test_errante_persigue_los_primeros_diez_turnos(self):
        self.assertEqual(self.fases(10), [self.objetivo] * 10)

    def test_errante_vuelve_a_su_esquina_los_diez_siguientes(self):
        self.fases(10)
        self.assertEqual(self.fases(10), [self.fantasma.inicio] * 10)

    def test_errante_vuelve_a_perseguir_en_el_tercer_ciclo(self):
        self.fases(20)
        self.assertEqual(self.fases(5), [self.objetivo] * 5)

    def test_errante_no_alterna_en_cada_turno(self):
        # el bug viejo daba el objetivo 9 veces y el inicio 1: eso NO es alternar
        fases = self.fases(20)
        self.assertEqual(fases.count(self.objetivo), 10)
        self.assertEqual(fases.count(self.fantasma.inicio), 10)

    def test_los_otros_estilos_no_usan_el_contador(self):
        for estilo in ("perseguidor", "emboscador", "timido"):
            fantasma = Fantasma((1, 1), estilo=estilo)
            fantasma.mover(self.lab, self.objetivo)
            self.assertEqual(getattr(fantasma, "_contador_errante", 0), 0,
                             f"{estilo} no debería mover el contador del errante")
